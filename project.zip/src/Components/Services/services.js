import React from 'react'
import Home from '../Homepage/home'

const Services = () => {
  return (
    <>
        <Home/>
    </>
  )
}

export default Services