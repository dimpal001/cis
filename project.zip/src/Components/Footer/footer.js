import React from "react";
import "./footer.css"

const Footer = () => {

    const year = new Date()

  return (
    <>
      <footer class="footer py-3 bg-light">
        <div class="container">
          <p class="text-center">&copy; All rights reserved. &nbsp; NEHU, Shillong {year.getFullYear()}</p>
        </div>
      </footer>
    </>
  );
};

export default Footer;
